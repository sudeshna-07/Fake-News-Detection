from pathlib import Path
import joblib
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "fake_news_pipeline.joblib"
DEMO_DATA_PATH = BASE_DIR / "data" / "demo_news.csv"

app = Flask(__name__)
# Allow the VS Code Live Server frontend to call the local Flask API.
CORS(app, resources={
    r"/api/*": {
        "origins": [
            "http://127.0.0.1:5500",
            "http://localhost:5500",
            "http://127.0.0.1:5501",
            "http://localhost:5501"
        ]
    }
})

pipeline = None
model_source = "not loaded"

def load_pipeline():
    global pipeline, model_source
    if MODEL_PATH.exists():
        pipeline = joblib.load(MODEL_PATH)
        model_source = "trained model"
        return
    # First-run convenience: train a tiny demonstration model so the UI opens immediately.
    # This is not suitable for real-world claims or academic performance reporting.
    from train_model import train
    train(str(DEMO_DATA_PATH), str(MODEL_PATH), demo_mode=True)
    pipeline = joblib.load(MODEL_PATH)
    model_source = "built-in demonstration data (replace with a labelled dataset for meaningful evaluation)"

load_pipeline()

@app.route("/", methods=["GET", "POST"])
def index():
    # Existing Flask-served interface remains available at http://127.0.0.1:5000.
    result = None
    confidence = None
    message = None
    headline = ""
    article_text = ""

    if request.method == "POST":
        headline = request.form.get("headline", "").strip()
        article_text = request.form.get("article_text", "").strip()
        combined = " ".join(part for part in [headline, article_text] if part).strip()

        if not combined:
            message = "Please enter a headline or article text."
        else:
            prediction = int(pipeline.predict([combined])[0])
            result = "FAKE" if prediction == 1 else "GENUINE"
            if hasattr(pipeline, "predict_proba"):
                probs = pipeline.predict_proba([combined])[0]
                confidence = round(float(max(probs)) * 100, 1)

    return render_template(
        "index.html",
        result=result,
        confidence=confidence,
        message=message,
        headline=headline,
        article_text=article_text,
        model_source=model_source
    )

@app.route("/api/predict", methods=["POST"])
def api_predict():
    """JSON API used by the separate Go Live frontend."""
    payload = request.get_json(silent=True) or {}
    headline = str(payload.get("headline", "")).strip()
    article_text = str(payload.get("article_text", "")).strip()
    combined = " ".join(part for part in [headline, article_text] if part).strip()

    if not combined:
        return jsonify({"error": "Enter a headline or article text."}), 400

    prediction = int(pipeline.predict([combined])[0])
    result = "FAKE" if prediction == 1 else "GENUINE"
    confidence = None
    if hasattr(pipeline, "predict_proba"):
        probs = pipeline.predict_proba([combined])[0]
        confidence = round(float(max(probs)) * 100, 1)

    return jsonify({
        "prediction": result,
        "confidence": confidence,
        "model_source": model_source,
        "disclaimer": "This is a text-pattern prediction, not proof that a claim is true or false."
    })

@app.route("/api/health", methods=["GET"])
def api_health():
    return jsonify({"status": "ok", "model_source": model_source})

if __name__ == "__main__":
    # Keep debug off for the local demo unless you specifically need the debugger.
    app.run(host="127.0.0.1", port=5000, debug=False)
