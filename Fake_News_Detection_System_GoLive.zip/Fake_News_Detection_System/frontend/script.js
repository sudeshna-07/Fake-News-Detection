const API_BASE = "http://127.0.0.1:5000";

const form = document.getElementById("news-form");
const headlineInput = document.getElementById("headline");
const articleInput = document.getElementById("article_text");
const button = document.getElementById("analyze-button");
const connection = document.getElementById("connection");
const message = document.getElementById("message");
const resultBox = document.getElementById("result");
const predictionEl = document.getElementById("prediction");
const confidenceEl = document.getElementById("confidence");
const disclaimerEl = document.getElementById("disclaimer");

function showMessage(text) {
  message.textContent = text;
  message.classList.remove("hidden");
}
function clearMessage() {
  message.textContent = "";
  message.classList.add("hidden");
}
function setConnection(online, text) {
  connection.classList.toggle("online", online);
  connection.classList.toggle("offline", !online);
  connection.classList.remove("checking");
  connection.innerHTML = '<span class="dot"></span>' + text;
}

async function checkBackend() {
  try {
    const response = await fetch(`${API_BASE}/api/health`);
    if (!response.ok) throw new Error("Health check failed");
    const data = await response.json();
    setConnection(true, `Flask connected · ${data.model_source}`);
  } catch (error) {
    setConnection(false, "Flask is offline — start app.py in VS Code");
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearMessage();
  resultBox.classList.add("hidden");

  const headline = headlineInput.value.trim();
  const article_text = articleInput.value.trim();
  if (!headline && !article_text) {
    showMessage("Please enter a headline or article text.");
    return;
  }

  button.disabled = true;
  button.textContent = "Analyzing…";
  try {
    const response = await fetch(`${API_BASE}/api/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ headline, article_text })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Prediction request failed.");

    predictionEl.textContent = data.prediction;
    resultBox.classList.remove("hidden", "fake", "genuine");
    resultBox.classList.add(data.prediction === "FAKE" ? "fake" : "genuine");
    confidenceEl.textContent = data.confidence == null
      ? "Confidence score is not available for this model."
      : `Model score for the predicted class: ${data.confidence}%`;
    disclaimerEl.textContent = data.disclaimer;
    resultBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
  } catch (error) {
    showMessage(`${error.message} Make sure Flask is running at ${API_BASE}.`);
    setConnection(false, "Could not connect to Flask backend");
  } finally {
    button.disabled = false;
    button.innerHTML = 'Analyze news <span aria-hidden="true">→</span>';
  }
});

checkBackend();
