from pathlib import Path
import argparse
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score

BASE_DIR = Path(__file__).resolve().parent

def normalize_dataset(df):
    """
    Supports common Kaggle Fake News dataset columns:
      - train.csv: title, text, label (1=fake, 0=real)
      - Fake.csv and True.csv: separate files are not merged automatically;
        combine them into a single CSV with a 'label' column first.
    Also supports a generic 'content' column.
    """
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    if "label" not in df.columns:
        raise ValueError("Dataset must contain a 'label' column (1=fake, 0=genuine).")

    text_parts = []
    if "title" in df.columns:
        text_parts.append(df["title"].fillna("").astype(str))
    if "text" in df.columns:
        text_parts.append(df["text"].fillna("").astype(str))
    if "content" in df.columns:
        text_parts.append(df["content"].fillna("").astype(str))
    if not text_parts:
        raise ValueError("Dataset needs at least one text column: 'title', 'text', or 'content'.")

    combined = text_parts[0]
    for part in text_parts[1:]:
        combined = combined + " " + part

    out = pd.DataFrame({"text": combined.str.replace(r"\s+", " ", regex=True).str.strip(),
                        "label": pd.to_numeric(df["label"], errors="coerce")})
    out = out.dropna(subset=["label"])
    out = out[out["text"].str.len() > 0]
    out["label"] = out["label"].astype(int)
    out = out[out["label"].isin([0, 1])]
    if out["label"].nunique() != 2:
        raise ValueError("After cleaning, the dataset must contain both labels 0 and 1.")
    return out

def build_pipeline(model_name="logistic"):
    if model_name == "passive-aggressive":
        classifier = PassiveAggressiveClassifier(max_iter=1000, random_state=42, tol=1e-3)
    else:
        classifier = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)
    return Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english", max_df=0.95, min_df=1,
                                  ngram_range=(1, 2), max_features=100000)),
        ("classifier", classifier)
    ])

def train(csv_path, output_path, model_name="logistic", demo_mode=False):
    df = pd.read_csv(csv_path)
    data = normalize_dataset(df)
    X_train, X_test, y_train, y_test = train_test_split(
        data["text"], data["label"], test_size=0.2, random_state=42, stratify=data["label"]
    )
    pipeline = build_pipeline(model_name)
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)

    print("\n=== Evaluation on held-out test data ===")
    print(f"Rows used: {len(data)}")
    print(f"Accuracy:  {accuracy_score(y_test, predictions):.4f}")
    print(f"Precision: {precision_score(y_test, predictions, zero_division=0):.4f}")
    print(f"Recall:    {recall_score(y_test, predictions, zero_division=0):.4f}")
    print(f"F1-score:  {f1_score(y_test, predictions, zero_division=0):.4f}")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, target_names=["GENUINE (0)", "FAKE (1)"], zero_division=0))
    print("Confusion matrix [rows=actual, columns=predicted]:")
    print(confusion_matrix(y_test, predictions))

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, output)
    print(f"\nSaved model to: {output}")
    if demo_mode:
        print("NOTE: This is a tiny synthetic demonstration dataset; its metrics are not meaningful.")
    return pipeline

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train a fake-news text classifier.")
    parser.add_argument("--data", default=str(BASE_DIR / "data" / "demo_news.csv"),
                        help="Path to labelled CSV. Expected label: 1=fake, 0=genuine.")
    parser.add_argument("--model", choices=["logistic", "passive-aggressive"], default="logistic")
    parser.add_argument("--output", default=str(BASE_DIR / "model" / "fake_news_pipeline.joblib"))
    parser.add_argument("--demo", action="store_true", help="Mark run as demonstration-only.")
    args = parser.parse_args()
    train(args.data, args.output, args.model, args.demo)
