# Fake News Detection System

A beginner-friendly Flask + scikit-learn project based on the supplied project presentation.

## Features
- Headline and article text input
- TF-IDF word and bigram features
- Logistic Regression by default
- Optional Passive-Aggressive model training
- Accuracy, precision, recall, F1-score, classification report, and confusion matrix
- Browser-based interface

## Important limitation
The included `data/demo_news.csv` contains tiny, synthetic examples so the application can start immediately. It is only a demonstration dataset. Its predictions and evaluation metrics are not suitable for academic claims or real-world fact-checking. Use a properly labelled dataset for project evaluation.

## 1. Open in VS Code
1. Extract `Fake_News_Detection_System.zip`.
2. In VS Code, choose **File → Open Folder**.
3. Select the extracted `Fake_News_Detection_System` folder.
4. Open **Terminal → New Terminal**.

## 2. Create a virtual environment

### Windows
```bash
py -m venv .venv
.venv\\Scripts\\activate
python -m pip install -r requirements.txt
```

### macOS
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

If activation is blocked in Windows PowerShell, use Command Prompt terminal or follow your institution's approved Python environment instructions.

## 3. Run the web app
```bash
python app.py
```
Open the local address printed in the terminal, usually `http://127.0.0.1:5000`.

The first run trains a small demonstration model automatically if no saved model exists.

## 4. Use a real labelled dataset
Download a labelled fake-news dataset from a trusted academic/Kaggle source. The training script accepts a CSV with:
- `label`: `1` = fake and `0` = genuine
- At least one of `title`, `text`, or `content`

For the common Kaggle Fake News dataset, `train.csv` usually has `title`, `text`, and `label`. Copy it into this folder as `data/train.csv`, then run:

```bash
python train_model.py --data data/train.csv --model logistic
```

To train the alternative model:
```bash
python train_model.py --data data/train.csv --model passive-aggressive
```

The trained pipeline is saved to `model/fake_news_pipeline.joblib`. Stop and restart `app.py` after training so the web app loads the updated model.

### Label conventions
This project expects `1 = fake` and `0 = genuine`. Verify your dataset's label definitions before training. If using separate `Fake.csv` and `True.csv` files, combine them into one CSV and add a `label` column first (fake=1, genuine=0).

## 5. Suggested project structure
```text
Fake_News_Detection_System/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── data/
│   └── demo_news.csv
├── model/                  # created after training
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## 6. What to explain in your presentation
1. Data collection: labelled news articles.
2. Preprocessing: combine headline/body and normalize whitespace.
3. Feature extraction: TF-IDF transforms text into sparse numerical features.
4. Model training: Logistic Regression or Passive-Aggressive classifier.
5. Evaluation: held-out test set and standard classification metrics.
6. Prediction: web interface accepts text and displays a class label.
7. Limitation: text patterns do not prove a claim is factually true.

## Troubleshooting
- `python` not found: install Python 3.10+ and enable the PATH option, or use `python3` on macOS.
- `ModuleNotFoundError`: activate `.venv` and run `python -m pip install -r requirements.txt`.
- CSV error: confirm the file path and required columns.
- Only one class found: confirm both labels 0 and 1 are present.
- Browser page cannot open: keep the terminal running and visit the exact local URL printed by Flask.


## Use VS Code Go Live with the Flask ML backend

The project now has a separate `frontend/` folder. Go Live serves only these static files; Flask runs the machine-learning API separately.

1. Install updated dependencies from the project root:
   ```powershell
   python -m pip install -r requirements.txt
   ```
2. Start Flask in VS Code terminal 1:
   ```powershell
   python app.py
   ```
   Keep this terminal running. Flask API uses `http://127.0.0.1:5000`.
3. In VS Code Explorer, open `frontend/index.html`, right-click it, and choose **Open with Live Server**. It will usually open at `http://127.0.0.1:5500/frontend/index.html` or another displayed Live Server URL.
4. Test a headline. The browser frontend sends JSON to `http://127.0.0.1:5000/api/predict`.
5. If Live Server chooses port 5501 or another port, add that exact origin to the allowed `origins` list in `app.py`, then restart Flask.
6. If the page says Flask is offline, check that the Flask terminal is still running and open `http://127.0.0.1:5000/api/health` in a browser.

The original Flask-rendered page remains available at `http://127.0.0.1:5000/`. Use the `frontend/` page when you want to demonstrate Go Live.
